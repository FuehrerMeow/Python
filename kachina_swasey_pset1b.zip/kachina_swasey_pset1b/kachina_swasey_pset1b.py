

total_cost = float(input("Please enter the total cost of your dream home: "))
annual_salary = float(input("Please enter your salary: "))
portion_saved = float(input("How much do you want to save annually: "))
semi_annual_raise = float(input("Please enter your raise as a decimal: "))
portion_down = (total_cost*.25)
current_savings = 0
monthly_salary = (annual_salary/12)
interest_rate = .04
portion_saved_monthly = monthly_salary*portion_saved
# use +=, or = current savings + 1
months = 1

while current_savings < portion_down:
    current_savings = current_savings + (current_savings*(0.04/12)) + portion_saved_monthly
    months = months + 1
    if months % 6 == 0:
        annual_salary = annual_salary + (annual_salary*semi_annual_raise)
        monthly_salary = annual_salary / 12
        portion_saved_monthly = monthly_salary*portion_saved

print("It will take", months, "months")

#asmnt pt 0
import numpy as numpy

x = input("please enter a number 'x'")
y = input("please enter a number 'y'")
print(int(x)**int(y))

x = int(x)
y = int(y)
print (x**y)
#x , 2 , print(), log
print(numpy.log2(x))
